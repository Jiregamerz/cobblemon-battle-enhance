package com.battleenhance.mixin;

import com.battleenhance.camera.CameraController;
import net.minecraft.class_310;
import net.minecraft.class_5498;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onRunTick(CallbackInfo ci) {
        // Handle game logic during battle
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onRender(CallbackInfo ci) {
        class_310 self = (class_310) (Object) this;

        if (CameraController.INSTANCE.isActive()) {
            if (self.field_1690.method_31044() != class_5498.field_26665) {
                self.field_1690.method_31043(class_5498.field_26665);
            }
        }
    }
}
