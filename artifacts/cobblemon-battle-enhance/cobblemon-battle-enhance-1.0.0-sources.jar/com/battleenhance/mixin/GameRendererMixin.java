package com.battleenhance.mixin;

import com.battleenhance.camera.CameraController;
import net.minecraft.class_310;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public abstract class GameRendererMixin {

    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void onRender(CallbackInfo ci) {
        class_310 client = class_310.method_1551();

        if (CameraController.INSTANCE.isActive() && client.field_1724 != null) {
            // Camera updates are handled in CameraController
        }
    }
}
