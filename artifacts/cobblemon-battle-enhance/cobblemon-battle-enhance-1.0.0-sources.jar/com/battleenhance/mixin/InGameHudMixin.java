package com.battleenhance.mixin;

import com.battleenhance.hud.BattleHUDRenderer;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class InGameHudMixin {

    @Inject(method = "render", at = @At("RETURN"))
    private void onRender(class_332 context, float tickDelta, CallbackInfo ci) {
        // Battle HUD is rendered via HudRenderCallback
    }
}
